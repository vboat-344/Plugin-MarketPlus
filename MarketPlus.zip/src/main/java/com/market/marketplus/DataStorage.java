package com.market.marketplus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.bukkit.inventory.ItemStack;

import java.io.*;
import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class DataStorage {
    
    private final MarketPlus plugin;
    private final Gson gson;
    private final File dataFolder;
    
    public DataStorage(MarketPlus plugin) {
        this.plugin = plugin;
        this.gson = new GsonBuilder()
                .setPrettyPrinting()
                .registerTypeAdapter(ItemStack.class, new ItemStackAdapter())
                .create();
        this.dataFolder = new File(plugin.getDataFolder(), "data");
        if (!dataFolder.exists()) dataFolder.mkdirs();
    }
    
    public void saveItems(Map<Integer, MarketItem> items) {
        File file = new File(dataFolder, "items.json");
        List<MarketItemData> dataList = new ArrayList<>();
        
        for (MarketItem item : items.values()) {
            dataList.add(new MarketItemData(item));
        }
        
        try (Writer writer = new FileWriter(file)) {
            gson.toJson(dataList, writer);
        } catch (IOException e) {
            plugin.getLogger().severe("Ошибка сохранения товаров: " + e.getMessage());
        }
    }
    
    public Map<Integer, MarketItem> loadItems() {
        Map<Integer, MarketItem> items = new ConcurrentHashMap<>();
        File file = new File(dataFolder, "items.json");
        
        if (!file.exists()) return items;
        
        try (Reader reader = new FileReader(file)) {
            Type type = new TypeToken<List<MarketItemData>>(){}.getType();
            List<MarketItemData> dataList = gson.fromJson(reader, type);
            
            if (dataList != null) {
                for (MarketItemData data : dataList) {
                    MarketItem item = data.toMarketItem();
                    if (item != null) {
                        items.put(item.getId(), item);
                    }
                }
            }
        } catch (IOException e) {
            plugin.getLogger().severe("Ошибка загрузки товаров: " + e.getMessage());
        }
        
        return items;
    }
    
    public void saveNextId(int nextId) {
        File file = new File(dataFolder, "nextid.json");
        try (Writer writer = new FileWriter(file)) {
            gson.toJson(Collections.singletonMap("nextId", nextId), writer);
        } catch (IOException e) {
            plugin.getLogger().severe("Ошибка сохранения ID: " + e.getMessage());
        }
    }
    
    public int loadNextId() {
        File file = new File(dataFolder, "nextid.json");
        if (!file.exists()) return 1;
        
        try (Reader reader = new FileReader(file)) {
            Map<String, Integer> map = gson.fromJson(reader, new TypeToken<Map<String, Integer>>(){}.getType());
            return map != null ? map.getOrDefault("nextId", 1) : 1;
        } catch (IOException e) {
            return 1;
        }
    }
    
    private static class MarketItemData {
        int id;
        UUID seller;
        String sellerName;
        ItemStack item;
        double price;
        long listedTime;
        
        MarketItemData(MarketItem item) {
            this.id = item.getId();
            this.seller = item.getSeller();
            this.sellerName = item.getSellerName();
            this.item = item.getItem();
            this.price = item.getPrice();
            this.listedTime = item.getListedTime();
        }
        
        MarketItem toMarketItem() {
            return new MarketItem(id, seller, sellerName, item, price, listedTime);
        }
    }
}