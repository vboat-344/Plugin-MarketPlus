package com.market.marketplus;

import org.bukkit.Material;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.stream.Collectors;

public class MarketCommand implements CommandExecutor, TabCompleter {
    private final MarketPlus plugin;
    private final Map<UUID, Double> pendingSales = new HashMap<>();
    
    public MarketCommand(MarketPlus plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Только для игроков!");
            return true;
        }
        Player p = (Player) sender;
        if (!p.hasPermission("market.use")) {
            p.sendMessage(plugin.getMessage("no-permission"));
            return true;
        }
        if (args.length == 0) {
            sendHelp(p);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "sell":
                if (!p.hasPermission("market.sell")) {
                    p.sendMessage(plugin.getMessage("no-permission"));
                    return true;
                }
                handleSell(p);
                break;
            case "buy":
                if (args.length != 2) {
                    p.sendMessage(plugin.getMessage("prefix") + "Используйте: /market buy <id>");
                    return true;
                }
                try {
                    int id = Integer.parseInt(args[1]);
                    plugin.getMarketManager().buyItem(p, id);
                } catch (NumberFormatException e) {
                    p.sendMessage(plugin.getMessage("invalid-id"));
                }
                break;
            case "list":
                List<MarketItem> items = plugin.getMarketManager().getPlayerItems(p.getUniqueId());
                if (items.isEmpty()) {
                    p.sendMessage(plugin.getMessage("listings-empty"));
                    return true;
                }
                int max = plugin.getConfig().getInt("settings.max-listings-per-player", 5);
                p.sendMessage(plugin.getMessage("your-listings-header")
                        .replace("{current}", String.valueOf(items.size()))
                        .replace("{max}", String.valueOf(max)));
                for (MarketItem mi : items) {
                    p.sendMessage(plugin.getMessage("listings-format")
                            .replace("{id}", String.valueOf(mi.getId()))
                            .replace("{item}", mi.getItemName())
                            .replace("{price}", String.valueOf(mi.getPrice())));
                }
                p.sendMessage(plugin.getMessage("prefix") + "&7Используйте /market cancel <id> или /market myitems");
                break;
            case "myitems":
                plugin.getMarketGUI().openMyItems(p);
                break;
            case "search":
                if (args.length < 2) {
                    p.sendMessage(plugin.getMessage("prefix") + "Используйте: /market search <ник>");
                    return true;
                }
                String searchName = args[1];
                List<MarketItem> found = plugin.getMarketManager().searchByPlayer(searchName);
                if (found.isEmpty()) {
                    p.sendMessage(plugin.getMessage("search-no-results"));
                    return true;
                }
                p.sendMessage(plugin.getMessage("listings-header").replace("{player}", searchName));
                for (MarketItem mi : found.stream().limit(10).collect(Collectors.toList())) {
                    p.sendMessage(plugin.getMessage("listings-format")
                            .replace("{id}", String.valueOf(mi.getId()))
                            .replace("{item}", mi.getItemName())
                            .replace("{price}", String.valueOf(mi.getPrice())));
                }
                break;
            case "cancel":
                if (args.length != 2) {
                    p.sendMessage(plugin.getMessage("prefix") + "Используйте: /market cancel <id>");
                    return true;
                }
                try {
                    int cancelId = Integer.parseInt(args[1]);
                    plugin.getMarketManager().cancelListing(p, cancelId);
                } catch (NumberFormatException e) {
                    p.sendMessage(plugin.getMessage("invalid-id"));
                }
                break;
            case "gui":
            case "market":
                plugin.getMarketGUI().openMarket(p, 1);
                break;
            case "reload":
                if (!p.hasPermission("market.admin")) {
                    p.sendMessage(plugin.getMessage("no-permission"));
                    return true;
                }
                plugin.reloadConfig();
                plugin.getMarketManager().saveAll();
                p.sendMessage(plugin.getMessage("reloaded"));
                break;
            default:
                sendHelp(p);
        }
        return true;
    }
    private void handleSell(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType() == Material.AIR) {
            player.sendMessage(plugin.getMessage("prefix") + "&cВозьмите предмет в руку!");
            return;
        }
        player.sendMessage(plugin.getMessage("enter-price"));
        pendingSales.put(player.getUniqueId(), null);
        plugin.getServer().getPluginManager().registerEvents(new org.bukkit.event.Listener() {
            @org.bukkit.event.EventHandler
            public void onChat(org.bukkit.event.player.AsyncPlayerChatEvent e) {
                if (!e.getPlayer().equals(player)) return;
                e.setCancelled(true);
                Double price = pendingSales.remove(player.getUniqueId());
                if (price == null && e.getMessage().equalsIgnoreCase("cancel")) {
                    player.sendMessage(plugin.getMessage("price-cancelled"));
                    org.bukkit.event.HandlerList.unregister(this);
                    return;
                }
                try {
                    double finalPrice = Double.parseDouble(e.getMessage());
                    if (finalPrice <= 0) throw new NumberFormatException();
                    plugin.getMarketManager().addItem(player, item, finalPrice);
                } catch (NumberFormatException ex) {
                    player.sendMessage(plugin.getMessage("invalid-price")
                            .replace("{min}", "10")
                            .replace("{max}", "90000000"));
                }
                org.bukkit.event.HandlerList.unregister(this);
            }
        }, plugin);
    }
    private void sendHelp(Player p) {
        p.sendMessage(plugin.colorize("&6=== MarketPlus Help ==="));
        p.sendMessage(plugin.colorize("&e/market gui &7- Открыть GUI магазина"));
        p.sendMessage(plugin.colorize("&e/market sell &7- Выставить предмет на продажу"));
        p.sendMessage(plugin.colorize("&e/market buy <id> &7- Купить предмет"));
        p.sendMessage(plugin.colorize("&e/market list &7- Список ваших товаров"));
        p.sendMessage(plugin.colorize("&e/market myitems &7- Ваши товары (GUI)"));
        p.sendMessage(plugin.colorize("&e/market search <ник> &7- Поиск товаров игрока"));
        p.sendMessage(plugin.colorize("&e/market cancel <id> &7- Снять товар"));
        if (p.hasPermission("market.admin")) {
            p.sendMessage(plugin.colorize("&c/market reload &7- Перезагрузить конфиг"));
        }
    }
    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (!(sender instanceof Player)) return new ArrayList<>();
        if (args.length == 1) {
            List<String> completions = Arrays.asList("gui", "sell", "buy", "list", "myitems", "search", "cancel");
            if (sender.hasPermission("market.admin")) completions.add("reload");
            return completions.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("buy")) {
            return plugin.getMarketManager().getAllItems().stream()
                    .limit(10)
                    .map(item -> String.valueOf(item.getId()))
                    .filter(id -> id.startsWith(args[1]))
                    .collect(Collectors.toList());
        }    
        return new ArrayList<>();
    }
}