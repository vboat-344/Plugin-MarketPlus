package com.market.marketplus;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class MarketGUI implements Listener {
    private final MarketPlus plugin;
    private final Map<UUID, Integer> playerPages = new HashMap<>();
    private final Map<UUID, String> playerSearch = new HashMap<>();
    public MarketGUI(MarketPlus plugin) {
        this.plugin = plugin;
    }
    public void openMarket(Player player, int page) {
        List<MarketItem> items = plugin.getMarketManager().getAllItems();
        int guiSize = plugin.getConfig().getInt("gui.market-size", 54);
        int itemsPerPage = guiSize - 9;
        int maxPages = (int) Math.ceil((double) items.size() / itemsPerPage);
        
        if (page < 1) page = 1;
        if (page > maxPages && maxPages > 0) page = maxPages;
        String title = plugin.colorize(plugin.getConfig().getString("gui.market-title", "&8Маркет")
                .replace("{page}", String.valueOf(page))
                .replace("{max}", String.valueOf(maxPages)));     
        Inventory inv = Bukkit.createInventory(null, guiSize, title);
        playerPages.put(player.getUniqueId(), page);
        int start = (page - 1) * itemsPerPage;
        int end = Math.min(start + itemsPerPage, items.size());
        int slot = 0;
        for (int i = start; i < end; i++) {
            MarketItem item = items.get(i);
            ItemStack display = item.getItem().clone();
            ItemMeta meta = display.getItemMeta();      
            List<String> lore = plugin.getConfig().getStringList("gui.items.info-item.lore");
            List<String> formattedLore = new ArrayList<>();
            for (String line : lore) {
                formattedLore.add(line
                        .replace("{seller}", item.getSellerName())
                        .replace("{price}", String.valueOf(item.getPrice()))
                        .replace("{id}", String.valueOf(item.getId())));
            }
            meta.setLore(formattedLore);
            meta.setDisplayName(plugin.colorize(plugin.getConfig().getString("gui.items.info-item.name", "&eИнформация")));
            display.setItemMeta(meta);
            
            inv.setItem(slot++, display);
        }
        addNavigationButtons(inv, page, maxPages);
        
        player.openInventory(inv);
        player.sendMessage(plugin.getMessage("gui-open"));
    }
    private void addNavigationButtons(Inventory inv, int currentPage, int maxPages) {
        int size = inv.getSize();
        if (currentPage > 1) {
            ItemStack prev = createGuiItem(
                    plugin.getConfig().getString("gui.items.prev-page.material", "ARROW"),
                    plugin.getConfig().getString("gui.items.prev-page.name", "&aПредыдущая"),
                    plugin.getConfig().getStringList("gui.items.prev-page.lore")
            );
            inv.setItem(size - 9, prev);
        }
        if (currentPage < maxPages) {
            ItemStack next = createGuiItem(
                    plugin.getConfig().getString("gui.items.next-page.material", "ARROW"),
                    plugin.getConfig().getString("gui.items.next-page.name", "&aСледующая"),
                    plugin.getConfig().getStringList("gui.items.next-page.lore")
            );
            inv.setItem(size - 8, next);
        }
        ItemStack sell = createGuiItem(
                plugin.getConfig().getString("gui.items.sell-button.material", "EMERALD"),
                plugin.getConfig().getString("gui.items.sell-button.name", "&a&lПродать"),
                plugin.getConfig().getStringList("gui.items.sell-button.lore")
        );
        inv.setItem(size - 4, sell);
        ItemStack refresh = createGuiItem(
                plugin.getConfig().getString("gui.items.refresh-button.material", "SUNFLOWER"),
                plugin.getConfig().getString("gui.items.refresh-button.name", "&a&lОбновить"),
                plugin.getConfig().getStringList("gui.items.refresh-button.lore")
        );
        inv.setItem(size - 3, refresh);
        ItemStack filler = createGuiItem(
                plugin.getConfig().getString("gui.items.filler.material", "BLACK_STAINED_GLASS_PANE"),
                plugin.getConfig().getString("gui.items.filler.name", " "),
                new ArrayList<>()
        );  
        for (int i = size - 8; i < size; i++) {
            if (inv.getItem(i) == null) inv.setItem(i, filler);
        }
    }  
    private ItemStack createGuiItem(String material, String name, List<String> lore) {
        ItemStack item = new ItemStack(Material.valueOf(material));
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(plugin.colorize(name));
        if (lore != null && !lore.isEmpty()) {
            List<String> coloredLore = new ArrayList<>();
            for (String line : lore) coloredLore.add(plugin.colorize(line));
            meta.setLore(coloredLore);
        }
        item.setItemMeta(meta);
        return item;
    } 
    public void openMyItems(Player player) {
        List<MarketItem> items = plugin.getMarketManager().getPlayerItems(player.getUniqueId());
        int guiSize = 54;
        String title = plugin.colorize(plugin.getConfig().getString("gui.myitems-title", "&8Мои товары"));
        Inventory inv = Bukkit.createInventory(null, guiSize, title);    
        int slot = 0;
        for (MarketItem item : items) {
            ItemStack display = item.getItem().clone();
            ItemMeta meta = display.getItemMeta();
            List<String> lore = new ArrayList<>();
            lore.add(plugin.colorize("&7Цена: &6" + item.getPrice() + "$"));
            lore.add(plugin.colorize("&7ID: &f" + item.getId()));
            lore.add("");
            lore.add(plugin.colorize("&cНажмите, чтобы снять с продажи"));
            meta.setLore(lore);
            meta.setDisplayName(plugin.colorize("&e" + item.getItemName()));
            display.setItemMeta(meta);
            inv.setItem(slot++, display);
        }
        
        player.openInventory(inv);
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        String title = event.getView().getTitle();
        
        if (title.contains(plugin.colorize("Магазин"))) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            int size = event.getInventory().getSize();
            if (slot == size - 9) {
                int page = playerPages.getOrDefault(player.getUniqueId(), 1);
                openMarket(player, page - 1);
            } else if (slot == size - 8) {
                int page = playerPages.getOrDefault(player.getUniqueId(), 1);
                openMarket(player, page + 1);
            } else if (slot == size - 4) {
                player.closeInventory();
                player.performCommand("market sell");
            } else if (slot == size - 3) {
                int page = playerPages.getOrDefault(player.getUniqueId(), 1);
                openMarket(player, page);
            } else if (slot < size - 9 && event.getCurrentItem() != null && event.getCurrentItem().getType() != Material.AIR) {
                ItemStack clicked = event.getCurrentItem();
                if (clicked.hasItemMeta() && clicked.getItemMeta().getLore() != null) {
                    for (String line : clicked.getItemMeta().getLore()) {
                        if (line.contains("ID:")) {
                            String idStr = line.substring(line.indexOf("ID:") + 4).trim();
                            try {
                                int id = Integer.parseInt(idStr);
                                plugin.getMarketManager().buyItem(player, id);
                                player.closeInventory();
                            } catch (NumberFormatException ignored) {}
                            break;
                        }
                    }
                }
            }
        } else if (title.contains(plugin.colorize("Мои товары"))) {
            event.setCancelled(true);
            if (event.getCurrentItem() != null && event.getCurrentItem().getType() != Material.AIR) {    
                ItemStack clicked = event.getCurrentItem();
                if (clicked.hasItemMeta() && clicked.getItemMeta().getLore() != null) {
                    for (String line : clicked.getItemMeta().getLore()) {
                        if (line.contains("ID:")) {
                            String idStr = line.substring(line.indexOf("ID:") + 4).trim();
                            try {
                                int id = Integer.parseInt(idStr);
                                plugin.getMarketManager().cancelListing(player, id);
                                player.closeInventory();
                                openMyItems(player);
                            } catch (NumberFormatException ignored) {}
                            break;
                        }
                    }
                }
            }
        }
    }
}