package com.market.marketplus;

import org.bukkit.inventory.ItemStack;
import java.util.UUID;

public class MarketItem {
    private final int id;
    private final UUID seller;
    private final String sellerName;
    private final ItemStack item;
    private final double price;
    private final long listedTime;
    public MarketItem(int id, UUID seller, String sellerName, ItemStack item, double price, long listedTime) {
        this.id = id;
        this.seller = seller;
        this.sellerName = sellerName;
        this.item = item.clone();
        this.price = price;
        this.listedTime = listedTime;
    }
    public int getId() { return id; }
    public UUID getSeller() { return seller; }
    public String getSellerName() { return sellerName; }
    public ItemStack getItem() { return item.clone(); }
    public double getPrice() { return price; }
    public long getListedTime() { return listedTime; }
    public String getItemName() {
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            return item.getItemMeta().getDisplayName();
        }
        String type = item.getType().toString().toLowerCase().replace("_", " ");
        return type.substring(0, 1).toUpperCase() + type.substring(1);
    }
}