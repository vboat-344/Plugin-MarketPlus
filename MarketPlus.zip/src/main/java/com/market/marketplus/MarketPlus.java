package com.market.marketplus;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class MarketPlus extends JavaPlugin {
    
    private static MarketPlus instance;
    private Economy economy;
    private MarketManager marketManager;
    private MarketGUI marketGUI;
    private DataStorage dataStorage;
    private FileConfiguration config;
    
    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        reloadConfig();
        config = getConfig();
        
        if (!setupEconomy()) {
            getLogger().severe("Vault/Economy не найден! Плагин отключён.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        
        this.dataStorage = new DataStorage(this);
        this.marketManager = new MarketManager(this);
        this.marketGUI = new MarketGUI(this);
        
        // Регистрация команд
        getCommand("market").setExecutor(new MarketCommand(this));
        getCommand("marketadmin").setExecutor(new MarketCommand(this));
        
        // Регистрация слушателей
        Bukkit.getPluginManager().registerEvents(new MarketGUI(this), this);
        
        getLogger().info("MarketPlus v" + getDescription().getVersion() + " включён!");
        getLogger().info("Загружено товаров: " + marketManager.getAllItems().size());
    }
    
    @Override
    public void onDisable() {
        if (marketManager != null) {
            marketManager.saveAll();
            getLogger().info("Сохранено товаров: " + marketManager.getAllItems().size());
        }
        getLogger().info("MarketPlus выключён.");
    }
    
    @Override
    public void reloadConfig() {
        super.reloadConfig();
        config = getConfig();
    }
    
    private boolean setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }
    
    public static MarketPlus getInstance() { return instance; }
    public Economy getEconomy() { return economy; }
    public MarketManager getMarketManager() { return marketManager; }
    public MarketGUI getMarketGUI() { return marketGUI; }
    public DataStorage getDataStorage() { return dataStorage; }
    
    public String colorize(String msg) {
        if (msg == null) return "";
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', msg);
    }
    
    public String getMessage(String path) {
        String msg = config.getString("messages." + path);
        return colorize(msg != null ? msg : "&cMessage not found: " + path);
    }
}