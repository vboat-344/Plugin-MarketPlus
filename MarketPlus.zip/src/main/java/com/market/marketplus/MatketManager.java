package com.market.marketplus;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class MarketManager {
    
    private final MarketPlus plugin;
    private final Map<Integer, MarketItem> items;
    private final Map<UUID, List<Integer>> playerItems;
    private int nextId;
    public MarketManager(MarketPlus plugin) {
        this.plugin = plugin;
        this.items = new ConcurrentHashMap<>();
        this.playerItems = new HashMap<>();
        this.items.putAll(plugin.getDataStorage().loadItems());
        this.nextId = plugin.getDataStorage().loadNextId();
        for (MarketItem item : items.values()) {
            playerItems.computeIfAbsent(item.getSeller(), k -> new ArrayList<>()).add(item.getId());
        }
        startAutoCleanup();
    }
    private void startAutoCleanup() {
        int days = plugin.getConfig().getInt("settings.auto-cleanup-days", 30);
        if (days > 0) {
            long millis = days * 24L * 60 * 60 * 1000;
            Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
                long now = System.currentTimeMillis();
                List<Integer> toRemove = new ArrayList<>();
                for (MarketItem item : items.values()) {
                    if (now - item.getListedTime() > millis) {
                        toRemove.add(item.getId());
                    }
                }
                for (int id : toRemove) {
                    removeItem(id, true);
                }
            }, 20 * 60 * 60, 20 * 60 * 60);
        }
    }
    public boolean addItem(Player seller, ItemStack item, double price) {
        int maxListings = plugin.getConfig().getInt("settings.max-listings-per-player", 5);
        List<Integer> sellerItems = playerItems.getOrDefault(seller.getUniqueId(), new ArrayList<>());
        if (sellerItems.size() >= maxListings) {
            seller.sendMessage(plugin.getMessage("max-listings").replace("{max}", String.valueOf(maxListings)));
            return false;
        }
        double minPrice = plugin.getConfig().getDouble("settings.min-price", 1);
        double maxPrice = plugin.getConfig().getDouble("settings.max-price", 0);
        if (price < minPrice || (maxPrice > 0 && price > maxPrice)) {
            String maxStr = maxPrice > 0 ? String.valueOf(maxPrice) : "∞";
            seller.sendMessage(plugin.getMessage("invalid-price")
                    .replace("{min}", String.valueOf(minPrice))
                    .replace("{max}", maxStr));
            return false;
        }
        int id = nextId++;
        MarketItem marketItem = new MarketItem(id, seller.getUniqueId(), seller.getName(), item, price, System.currentTimeMillis());
        items.put(id, marketItem);
        sellerItems.add(id);
        playerItems.put(seller.getUniqueId(), sellerItems);
        item.setAmount(1);
        seller.getInventory().removeItem(item);
        String itemName = marketItem.getItemName();
        seller.sendMessage(plugin.getMessage("listing-created")
                .replace("{item}", itemName)
                .replace("{price}", String.valueOf(price)));
        saveAll();
        return true;
    }
    public boolean buyItem(Player buyer, int id) {
        MarketItem item = items.get(id);
        if (item == null) {
            buyer.sendMessage(plugin.getMessage("item-sold"));
            return false;
        }
        double price = item.getPrice();
        if (!plugin.getEconomy().has(buyer, price)) {
            buyer.sendMessage(plugin.getMessage("not-enough-money"));
            return false;
        }
        if (buyer.getInventory().firstEmpty() == -1) {
            buyer.sendMessage(plugin.getMessage("inventory-full"));
            return false;
        }
        plugin.getEconomy().withdrawPlayer(buyer, price);
        buyer.getInventory().addItem(item.getItem());
        double taxPercent = plugin.getConfig().getDouble("settings.tax-percent", 0);
        double tax = price * (taxPercent / 100);
        double sellerGain = price - tax;
        Player seller = Bukkit.getPlayer(item.getSeller());
        if (seller != null && seller.isOnline()) {
            plugin.getEconomy().depositPlayer(seller, sellerGain);
            seller.sendMessage(plugin.getMessage("sold-message")
                    .replace("{item}", item.getItemName())
                    .replace("{price}", String.valueOf(price))
                    .replace("{tax}", String.valueOf(tax)));
        } else {
            plugin.getEconomy().depositPlayer(item.getSeller(), sellerGain);
        }
        Bukkit.broadcastMessage(plugin.getMessage("buy-broadcast")
                .replace("{player}", buyer.getName())
                .replace("{item}", item.getItemName())
                .replace("{seller}", item.getSellerName())
                .replace("{price}", String.valueOf(price)));
        removeItem(id);
        return true;
    }
    public void removeItem(int id) {
        removeItem(id, false);
    }
    private void removeItem(int id, boolean silent) {
        MarketItem item = items.remove(id);
        if (item == null) return;
        List<Integer> sellerItems = playerItems.get(item.getSeller());
        if (sellerItems != null) {
            sellerItems.remove((Integer) id);
            if (sellerItems.isEmpty()) {
                playerItems.remove(item.getSeller());
            }
        }
        if (!silent) {
            Player seller = Bukkit.getPlayer(item.getSeller());
            if (seller != null) {
                seller.sendMessage(plugin.getMessage("listing-removed")
                        .replace("{item}", item.getItemName())
                        .replace("{id}", String.valueOf(id)));
            }
        }
        saveAll();
    }
    public void cancelListing(Player player, int id) {
        MarketItem item = items.get(id);
        if (item == null || !item.getSeller().equals(player.getUniqueId())) {
            player.sendMessage(plugin.getMessage("invalid-id"));
            return;
        }
        if (player.getInventory().firstEmpty() == -1) {
            player.sendMessage(plugin.getMessage("inventory-full"));
            return;
        }
        player.getInventory().addItem(item.getItem());
        String itemName = item.getItemName();
        removeItem(id);
        player.sendMessage(plugin.getMessage("listing-removed")
                .replace("{item}", itemName)
                .replace("{id}", String.valueOf(id)));
    }
    public List<MarketItem> getPlayerItems(UUID uuid) {
        List<Integer> ids = playerItems.getOrDefault(uuid, new ArrayList<>());
        return ids.stream()
                .map(items::get)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }
    public List<MarketItem> getAllItems() {
        return new ArrayList<>(items.values());
    }
    public List<MarketItem> searchByPlayer(String playerName) {
        return getAllItems().stream()
                .filter(item -> item.getSellerName().equalsIgnoreCase(playerName))
                .collect(Collectors.toList());
    }
    public MarketItem getItem(int id) {
        return items.get(id);
    }
    public void saveAll() {
        plugin.getDataStorage().saveItems(items);
        plugin.getDataStorage().saveNextId(nextId);
    }
}